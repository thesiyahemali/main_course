import React from 'react'
import ChildC from './03_ChildC'

const ChildB = () => {
  return (
    <div>
      <ChildC/>
      <h1>hiii i am b </h1>
    </div>
  )
}

export default ChildB
