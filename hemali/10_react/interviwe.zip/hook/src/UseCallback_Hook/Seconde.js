import React,{memo} from 'react'

const Seconde = ({todo,changjeb}) => {

  console.log('componet seconde');

  return (
    <>
     <h1>hii</h1>
    </>
  )
}

export default memo(Seconde)